import React, { useState } from 'react';

function StudentRegistrationForm() {
  const [students, setStudents] = useState([]);

  const handleSubmit = (e) => {
    e.preventDefault();

    const form = e.target;

    const newStudent = {
      fullname: form.fullname.value.trim(),
      email: form.email.value.trim(),
      dob: form.dob.value,
      gender: form.gender.value,
      department: form.department.value,
      skills: Array.from(form.skills)
        .filter((skill) => skill.checked)
        .map((skill) => skill.value)
        .join(', '),
      address: form.address.value.trim(),
    };

    setStudents([...students, newStudent]);
    alert(`Student "${newStudent.fullname}" from "${newStudent.department}" department has been registered successfully!`);
    form.reset();
  };

  const handleDelete = (index) => {
    const updatedStudents = [...students];
    updatedStudents.splice(index, 1);
    setStudents(updatedStudents);
  };

  return (
    <div style={styles.container}>
      <form id="regform" onSubmit={handleSubmit}>
        <h2>Student Registration Form</h2>

        <label htmlFor="fullname">Full Name:</label><br />
        <input type="text" id="fullname" name="fullname" required /><br /><br />

        <label htmlFor="email">Email:</label><br />
        <input type="email" id="email" name="email" required /><br /><br />

        <label htmlFor="password">Password:</label><br />
        <input type="password" id="password" name="password" required /><br /><br />

        <label htmlFor="dob">Date of Birth:</label><br />
        <input type="date" id="dob" name="dob" required /><br /><br />

        <label>Gender:</label><br />
        <input type="radio" id="male" name="gender" value="male" required />
        <label htmlFor="male">Male</label>

        <input type="radio" id="female" name="gender" value="female" />
        <label htmlFor="female">Female</label><br /><br />

        <label htmlFor="department">Department:</label><br />
        <select id="department" name="department" required>
          <option value="">--Select--</option>
          <option value="cse">Computer Science</option>
          <option value="ece">Electronics</option>
          <option value="eee">Electrical</option>
          <option value="mech">Mechanical</option>
          <option value="civil">Civil</option>
          <option value="it">Information Technology</option>
        </select><br /><br />

        <label>Skills:</label><br />
        <input type="checkbox" id="html" name="skills" value="HTML" />
        <label htmlFor="html">HTML</label>

        <input type="checkbox" id="css" name="skills" value="CSS" />
        <label htmlFor="css">CSS</label>

        <input type="checkbox" id="js" name="skills" value="JavaScript" />
        <label htmlFor="js">JavaScript</label>

        <input type="checkbox" id="react" name="skills" value="React" />
        <label htmlFor="react">React</label><br /><br />

        <label htmlFor="address">Address:</label><br />
        <textarea id="address" name="address" rows="4" cols="30"></textarea><br /><br />

        <label htmlFor="photo-upload">Upload Photo:</label><br />
        <input type="file" id="photo-upload" name="photo" /><br /><br />

        <button type="submit" style={styles.submitButton}>Submit</button>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <button type="reset" style={styles.resetButton}>Reset</button>
      </form>

      {students.length > 0 && (
        <table style={styles.table}>
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>DOB</th>
              <th>Gender</th>
              <th>Department</th>
              <th>Skills</th>
              <th>Address</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {students.map((student, index) => (
              <tr key={index}>
                <td>{student.fullname}</td>
                <td>{student.email}</td>
                <td>{student.dob}</td>
                <td>{student.gender}</td>
                <td>{student.department}</td>
                <td>{student.skills}</td>
                <td>{student.address}</td>
                <td>
                  <button onClick={() => handleDelete(index)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}


const styles = {
  container: {
    color: 'brown',
    textAlign: 'center',
    border: '10px solid black',
    backgroundColor: 'pink',
    borderRadius: '10%',
    marginBottom: '40px',
    marginTop: '25px',
    width: '100%',
    padding: '20px',
    fontFamily: `'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif`,
    background: 'rgb(15, 236, 111)',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  
  submitButton: {
    backgroundColor: 'aqua',
    color: 'black',
    padding: '10px 20px',
    border: 'none',
    borderRadius: '8px',
    fontWeight: 'bold',
  },
  resetButton: {
    backgroundColor: 'orange',
    color: 'white',
    padding: '10px 20px',
    border: 'none',
    borderRadius: '8px',
    fontWeight: 'bold',
  },
  table: {
    border: '1px solid rgb(230, 10, 10)',
    borderCollapse: 'collapse',
    padding: '10px',
    marginBottom: '30px',
    backgroundColor: 'white',
  }
};

export default StudentRegistrationForm;
